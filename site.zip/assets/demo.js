/* REVISION – interaktyvus demo v2. Visi duomenys išgalvoti. Jokių tinklo užklausų. */
(function(){
  'use strict';
  var $=function(s,r){return (r||document).querySelector(s);};
  var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function fmt(n,d){return Number(n).toLocaleString('lt-LT',{minimumFractionDigits:d||0,maximumFractionDigits:d||0});}
  function eur(n){return (n<0?'−':(n>0?'+':''))+fmt(Math.abs(n),2)+' €';}
  function sgn(n){return n===0?'0':(n<0?'−'+fmt(Math.abs(n)):'+'+fmt(n));}
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function ean(body){var s='200'+body,t=0;for(var i=0;i<12;i++){t+=(+s[i])*(i%2?3:1);}return s+((10-t%10)%10);}
  var timers=[];function later(fn,ms){var t=setTimeout(fn,reduce?0:ms);timers.push(t);return t;}
  function clearTimers(){timers.forEach(clearTimeout);timers=[];}

  /* ---------- išgalvoti duomenys ---------- */
  var W=['Darbuotojas 1','Darbuotojas 2','Darbuotojas 3','Darbuotojas 4'];
  // locs: pirmas skaičiavimas [lokacija, lentyna, darbuotojo nr, kiekis]; fix: perpatikrinimo pataisa
  var P=[
    {k:'VP-0001',n:'Varžtas M8x40 DIN933',u:'vnt.',b:'000100010',buh:400,pr:0.18,locs:[['00001',1,0,200],['00004',2,1,150]],fix:{i:1,q:200}},
    {k:'VP-0002',n:'Veržlė M8 DIN934',u:'vnt.',b:'000100020',buh:1000,pr:0.06,locs:[['00001',2,0,1000]]},
    {k:'VP-0003',n:'Poveržlė M8 DIN125',u:'vnt.',b:'000100030',buh:2000,pr:0.03,locs:[['00002',1,0,1000],['00002',2,0,1000]]},
    {k:'DZ-0101',n:'Dažai balti 10 l',u:'vnt.',b:'000201010',buh:36,pr:32.90,locs:[['00003',1,1,34]]},
    {k:'DZ-0102',n:'Gruntas universalus 5 l',u:'vnt.',b:'000201020',buh:20,pr:14.50,locs:[['00004',1,1,20]]},
    {k:'SL-0201',n:'Silikonas skaidrus 300 ml',u:'vnt.',b:'000202010',buh:120,pr:4.20,locs:[['00005',1,2,96]],fix:{i:0,q:120}},
    {k:'SL-0202',n:'Montavimo putos 750 ml',u:'vnt.',b:'000202020',buh:48,pr:7.40,locs:[['00006',1,2,45]]},
    {k:'EL-0301',n:'Kabelis NYM 3x1,5',u:'m',b:'000303010',buh:1000,pr:0.65,locs:[['00007',1,3,1100]]},
    {k:'EL-0302',n:'Izoliacinė juosta 19 mm',u:'vnt.',b:'000303020',buh:200,pr:0.95,locs:[['00008',1,3,210]]},
    {k:'EL-0303',n:'Kištukinis lizdas IP44',u:'vnt.',b:'000303030',buh:30,pr:6.85,locs:[['00008',2,3,28]]}
  ];
  P.forEach(function(p){
    p.e=ean(p.b);
    p.c1=p.locs.reduce(function(a,l){return a+l[3];},0);
    p.fin=p.locs.map(function(l,i){return (p.fix&&p.fix.i===i)?p.fix.q:l[3];});
    p.c2=p.fin.reduce(function(a,q){return a+q;},0);
  });
  var LOCS=['00001','00002','00003','00004','00005','00006','00007','00008'];
  // laiko juosta: [priskirta, pradėta, uždaryta] (žingsniais)
  var TL={'00001':[0,0,1],'00002':[0,1,2],'00003':[0,0,2],'00004':[1,1,3],'00005':[0,1,3],'00006':[2,2,4],'00007':[1,2,3],'00008':[2,3,4]};
  var RC={'00001':'Darbuotojas 3','00003':'Darbuotojas 4','00004':'Darbuotojas 3','00005':'Darbuotojas 1','00006':'Darbuotojas 1','00007':'Darbuotojas 2','00008':'Darbuotojas 2'};
  function locWorker(l){for(var i=0;i<P.length;i++){for(var j=0;j<P[i].locs.length;j++){if(P[i].locs[j][0]===l)return W[P[i].locs[j][2]];}}return '';}
  function locStats(l){var rows=0,q=0;P.forEach(function(p){p.locs.forEach(function(x){if(x[0]===l){rows++;q+=x[3];}});});return {rows:rows,q:q};}

  /* ---------- navigacija ---------- */
  var LABELS=['Paslauga','Schema','Pasiruošimas','Prisijungimas','Importas','Skenavimas','Lokacijos','Nomenklatūra','Perpatikrinimas','Skirtumai','Eksportas','Kainos'];
  var STAGE=['','','1 · Pasiruošimas','1 · Pasiruošimas','1 · Pasiruošimas','2 · Skaičiavimas ir kontrolė','2 · Skaičiavimas ir kontrolė','2 · Skaičiavimas ir kontrolė','3 · Perpatikrinimas','Rezultatas','Rezultatas',''];
  var GROUP=[0,0,1,1,1,2,2,2,3,0,0,0];
  var LAST=11, cur=0, screens=$$('.screen');
  var ol=$('#stepsNav ol');
  LABELS.forEach(function(t,i){
    var li=document.createElement('li'); if(GROUP[i]) li.className='g'+GROUP[i];
    li.innerHTML='<button type="button" data-go="'+i+'" aria-label="'+(i)+'. '+t+'"><span class="n">'+i+'</span><span class="t">'+t+'</span></button>';
    ol.appendChild(li);
  });
  function show(n,focus){
    n=Math.max(0,Math.min(LAST,n)); clearTimers(); cur=n;
    screens.forEach(function(s){s.hidden=(+s.dataset.screen!==n);});
    $('#pager').hidden=(n===0);
    $$('#stepsNav button').forEach(function(b){var k=+b.dataset.go; if(k===n)b.setAttribute('aria-current','step'); else b.removeAttribute('aria-current'); b.classList.toggle('done',k<n);});
    $('#pagerPos').textContent=n+' / '+LAST;
    $('#stagePill').textContent=STAGE[n];
    $('#nextBtn').disabled=(n===LAST);
    var hash=n===0?'':'#'+n;
    if(location.hash!==hash) history.replaceState(null,'',hash||location.pathname);
    if(INIT[n]) INIT[n]();
    window.scrollTo(0,0);
    if(focus!==false){var h=$('h1,h2',screens[n]); if(h) h.focus({preventScroll:true});}
  }
  $('#startBtn').addEventListener('click',function(){show(1);});
  $('#prevBtn').addEventListener('click',function(){show(cur-1);});
  $('#nextBtn').addEventListener('click',function(){show(cur+1);});
  $('#restartBtn').addEventListener('click',function(){resetAll();show(0);});
  $('#stepsNav').addEventListener('click',function(e){var b=e.target.closest('button[data-go]'); if(b) show(+b.dataset.go);});
  document.addEventListener('keydown',function(e){
    if(e.altKey||e.ctrlKey||e.metaKey) return;
    var t=e.target.tagName; if(t==='INPUT'||t==='TEXTAREA'||t==='SELECT') return;
    if(!$('#modal').hidden){ if(e.key==='Escape') closeModal(); return; }
    if(e.target.getAttribute('role')==='tab') return;
    if(e.key==='ArrowRight') show(cur+1); else if(e.key==='ArrowLeft') show(cur-1);
  });
  function fromHash(){var n=parseInt(location.hash.replace('#',''),10);return (n>=0&&n<=LAST)?n:0;}
  window.addEventListener('hashchange',function(){show(fromHash());});
  var INIT={};

  /* ---------- 1 schema ---------- */
  function setTime(t){
    $('#scheme').dataset.time=t;
    $$('[data-time]').forEach(function(b){ if(b.classList.contains('seg')) b.setAttribute('aria-pressed',String(b.dataset.time===String(t))); });
    $('#schemeSum').innerHTML = t==1
      ? '<strong>1-as kartas:</strong> visi 3 etapai <strong>su Grantu</strong> + programos nuoma.'
      : '<strong>Kiti kartai:</strong> Jūs dirbate <strong>patys</strong>. Mokate tik už <strong>programos nuomą</strong>.';
  }
  $$('.seg[data-time]').forEach(function(b){b.addEventListener('click',function(){setTime(+b.dataset.time);});});
  INIT[1]=function(){ setTime($('#scheme').dataset.time||1); };

  /* ---------- 2 prisijungimas ---------- */
  function qrSvg(){
    var N=25,s=7,m=[],seed=42; function rnd(){seed=(seed*16807)%2147483647;return seed/2147483647;}
    for(var y=0;y<N;y++){m[y]=[];for(var x=0;x<N;x++)m[y][x]=rnd()>0.52;}
    function finder(ox,oy){for(var y=-1;y<8;y++)for(var x=-1;x<8;x++){var X=ox+x,Y=oy+y;if(X<0||Y<0||X>=N||Y>=N)continue;var d=Math.max(Math.abs(x-3),Math.abs(y-3));m[Y][X]=(d===3||d<=1)&&x>=0&&y>=0&&x<7&&y<7;}}
    finder(0,0);finder(N-7,0);finder(0,N-7);
    var r='';for(var y2=0;y2<N;y2++)for(var x2=0;x2<N;x2++)if(m[y2][x2])r+='<rect x="'+x2*s+'" y="'+y2*s+'" width="'+s+'" height="'+s+'"/>';
    return '<svg viewBox="0 0 '+N*s+' '+N*s+'" aria-hidden="true"><g fill="#0B3A57">'+r+'</g></svg>';
  }
  $('#qr').innerHTML=qrSvg();
  $('#lgSend').addEventListener('click',function(){
    this.hidden=true; $('#lgCode').hidden=false;
    $('#hint2').innerHTML='Laiškas atėjo. Spauskite <strong>„Įvesti kodą“</strong>.';
    $('#lgEnter').focus();
  });
  $('#lgEnter').addEventListener('click',function(){
    var btn=this; btn.disabled=true; var code='482913', boxes=$$('#codeBoxes span');
    boxes.forEach(function(b,i){later(function(){b.textContent=code[i];},120*i);});
    later(function(){
      $('#lgCode').hidden=true; $('#lgQr').hidden=false;
      var h=$('#hint2'); h.className='hint ok'; h.innerHTML='Puiku! Dabar <strong>nuskenuokite QR</strong> ir įsidiekite programą.';
    },900);
  });
  function resetLogin(){ $('#lgSend').hidden=false; $('#lgCode').hidden=true; $('#lgQr').hidden=true; $('#lgEnter').disabled=false; $$('#codeBoxes span').forEach(function(b){b.textContent='';}); var h=$('#hint2'); h.className='hint'; h.innerHTML='Spauskite <strong>„Siųsti kodą“</strong>.'; }

  /* ---------- 3 importas ---------- */
  var imp={};
  function impDone(id,html){ var c=$('#'+id); c.classList.add('done'); $('.res',c).innerHTML=html; updImp(); }
  function updImp(){
    var need=['impNom','impStock','impLoc','impWrk'], left=need.filter(function(id){return !$('#'+id).classList.contains('done');}).length;
    var h=$('#hint3');
    if(!left){ h.className='hint ok'; h.innerHTML='Viskas paruošta. <strong>Galima skenuoti!</strong>'; }
    else { h.className='hint'; h.innerHTML='Paspauskite <strong>kiekvieną kortelę</strong>. Liko: <b id="impLeft">'+left+'</b>.'; }
  }
  $('#withStock').addEventListener('change',function(){
    var st=$('#impStock');
    if(imp.nom){ if(this.checked){ impDone('impStock','✓ Likučiai jau įkelti su nomenklatūra'); } }
  });
  $$('[data-imp]').forEach(function(b){b.addEventListener('click',function(){
    var t=b.dataset.imp; b.classList.add('is-done');
    if(t==='nom'){ imp.nom=1; impDone('impNom','✓ Įkelta: <strong>1200</strong> prekių'+($('#withStock').checked?' su likučiais':''));
      if($('#withStock').checked) impDone('impStock','✓ Likučiai jau įkelti su nomenklatūra'); }
    if(t==='stock'){ impDone('impStock','✓ Įkelti likučiai: <strong>1200</strong> eil.'); }
    if(t==='locgen'||t==='locxls'){
      var chips=LOCS.map(function(l){return '<span>'+l+'</span>';}).join('')+'<span>…</span>';
      impDone('impLoc',(t==='locgen'?'✓ Sugeneruota: <strong>00001–00120</strong>':'✓ Importuota iš Excel: <strong>120</strong> lokacijų')+'<span class="chips">'+chips+'</span>');
      $$('#impLoc [data-imp]').forEach(function(x){x.classList.toggle('is-done',x===b);});
    }
    if(t==='wrkadd'||t==='wrkxls'){
      impDone('impWrk','✓ '+(t==='wrkadd'?'Įvesta':'Importuota')+': <strong>4</strong> darbuotojai<span class="chips">'+W.map(function(w){return '<span>'+w+'</span>';}).join('')+'</span>');
      $$('#impWrk [data-imp]').forEach(function(x){x.classList.toggle('is-done',x===b);});
    }
  });});
  function resetImp(){ imp={}; $$('.imp').forEach(function(c){c.classList.remove('done'); $('.res',c).innerHTML='';}); $$('[data-imp]').forEach(function(b){b.classList.remove('is-done');}); $('#withStock').checked=true; updImp(); }

  /* ---------- telefono dalys ---------- */
  function pStatus(){return '<div class="p-status"><span>09:41</span><span>4G ▮ 87%</span></div>';}
  function tilesHtml(a,b,c,d){return '<div class="p-tiles"><div class="tb"><b>'+a+'</b>Nepradėtos</div><div class="ty"><b>'+b+'</b>Pradėtos</div><div class="tg"><b>'+c+'</b>Uždarytos</div><div class="tx"><b>'+d+'</b>Laisvos</div></div>';}

  /* ---------- 4 skenavimas ---------- */
  var s4={st:0,scans:0};
  var SCANS=[{p:2,sh:1,q:1000},{p:2,sh:2,q:1000}];
  function ph4(){
    var ph=$('#ph4'), h='', btn=$('#ph4Btn'), st=s4.st;
    if(st===0){
      h=pStatus()+'<div class="p-bar">REVISION – inventorizacija <span>⋮</span></div><div class="p-body">'+
        '<div class="p-logo"><img src="assets/brand/revision-logo-horizontal.svg" alt="" width="150" height="32"></div>'+
        '<div class="p-field"><small>Įmonė</small><b>UAB Pavyzdys</b> ▾</div>'+
        '<div class="p-field"><small>Vartotojas</small><b>Darbuotojas 1</b> ▾</div>'+
        '<div class="p-card"><small>Šiandien</small><br><b>2026-12-30</b></div>'+
        '<div class="p-big">PRADĖTI DARBĄ<small>▸ pradedamas darbo laiko skaičiavimas</small></div></div>';
      btn.textContent='Prisijungti';
    } else if(st===1||st===4){
      var done=st===4;
      h=pStatus()+'<div class="p-bar"><span class="p-hdr-btn y">Atsijungti</span><span>Darbuotojas 1</span><span>⋮</span></div><div class="p-body">'+
        '<div><small>Nom.: <b>1200</b></small></div>'+tilesHtml(done?0:1,1,done?1:0,6)+
        '<div class="p-field"><small>Nuskenuokite lokaciją</small><b>'+(done?'&nbsp;':'00002')+'</b></div>'+
        (done?'<div class="p-loc g flash">00002</div>':'<div class="p-loc b">00002</div>')+
        '<div class="p-loc y">00001</div></div>';
      btn.textContent=done?'Lokacija uždaryta ✓':'Atidaryti lokaciją 00002';
      btn.disabled=done;
    } else if(st===2||st===3){
      var rows=SCANS.slice(0,s4.scans), qty=rows.reduce(function(a,r){return a+r.q;},0), sh=rows.length?rows[rows.length-1].sh:1;
      var shelves={}; rows.forEach(function(r){shelves[r.sh]=1;});
      h=pStatus()+'<div class="p-bar"><span>00002<small>Darbuotojas 1</small></span><span class="p-hdr-btn">🔒 Uždaryti<br>lokaciją</span></div><div class="p-body">'+
        '<div class="p-row"><span class="p-btn p-red">−</span><span class="p-btn" style="background:#fff">Lentyna <b>'+sh+'</b></span><span class="p-btn p-grn">+</span></div>'+
        '<div class="p-field"><small>Skenuokite barkodą</small><b>'+(rows.length?esc(P[2].e):'&nbsp;')+'</b></div>'+
        '<div class="p-row"><span class="p-btn p-lgr">+1<small>po 1</small></span><span class="p-btn p-gry">123<small>Kiekis</small></span></div>'+
        '<div class="p-sum"><div><b>'+rows.length+'</b>Eilučių</div><div><b>'+(rows.length?1:0)+'</b>Prekių</div><div><b>'+fmt(qty)+'</b>Kiekis</div><div><b>'+Object.keys(shelves).length+'</b>Lentynų</div></div>'+
        rows.slice().reverse().map(function(r){var p=P[r.p];return '<div class="p-item"><div><span class="ean">'+p.e+'</span> '+esc(p.k)+'<br>'+esc(p.n)+'<br>Lentyna: '+r.sh+'</div><b class="q">'+fmt(r.q)+'</b></div>';}).join('')+
        '</div>';
      if(st===3) h+='<div class="p-dialog"><div class="box"><h4>Ar norite uždaryti lokaciją?</h4><div class="p-row"><span class="p-btn p-red">Ne</span><span class="p-btn p-grn">Taip</span></div></div></div>';
      btn.textContent= st===3?'Taip – uždaryti':(s4.scans<SCANS.length?'Skenuoti prekę ('+(s4.scans+1)+'/'+SCANS.length+')':'Uždaryti lokaciją');
    }
    ph.innerHTML=h;
    var k=st===0?0:(st===1?1:(st===2?2:3));
    $$('#flow4 li').forEach(function(li){var i=+li.dataset.k; li.className=i<k||(st===4)?'done':(i===k?'cur':'');});
  }
  $('#ph4Btn').addEventListener('click',function(){
    if(s4.st===0) s4.st=1;
    else if(s4.st===1) s4.st=2;
    else if(s4.st===2){ if(s4.scans<SCANS.length) s4.scans++; else s4.st=3; }
    else if(s4.st===3) s4.st=4;
    ph4();
  });
  INIT[5]=ph4;

  /* ---------- 5 lokacijos ---------- */
  var locT=0;
  function locStatus(l,t){var x=TL[l]; if(t>=x[2])return 3; if(t>=x[1])return 2; if(t>=x[0])return 1; return 0;}
  var ST=[['Laisva','st-x'],['Priskirta','st-b'],['Pradėta','st-y'],['Uždaryta','st-g']];
  function renderLocs(){
    var c=[0,0,0,0], body='';
    LOCS.forEach(function(l){
      var s=locStatus(l,locT); c[s]++; var st=locStats(l), part=s===2?0.5:(s===3?1:0);
      body+='<tr><td data-label="Lokacija"><b>'+l+'</b></td><td data-label="1 skaičiavimas">'+(s?locWorker(l):'<span class="muted">–</span>')+'</td>'+
        '<td data-label="2 skaičiavimas">'+(s===3?(RC[l]?'<strong>'+RC[l]+'</strong>':'<span class="muted">nereikia – skirtumų nėra</span>'):'<span class="muted">–</span>')+'</td>'+
        '<td data-label="Būsena"><span class="st '+ST[s][1]+'">'+ST[s][0]+'</span></td>'+
        '<td data-label="Eilučių" class="num">'+(part?Math.max(1,Math.round(st.rows*part)):0)+'</td>'+
        '<td data-label="Kiekis" class="num">'+fmt(Math.round(st.q*part))+'</td></tr>';
    });
    $('#locBody').innerHTML=body;
    $('#locTiles').innerHTML='<div class="tb"><b>'+c[1]+'</b>Nepradėtos</div><div class="ty"><b>'+c[2]+'</b>Pradėtos</div><div class="tg"><b>'+c[3]+'</b>Uždarytos</div><div class="tx"><b>'+c[0]+'</b>Laisvos</div>';
    var b=$('#locTick'); b.disabled=locT>=4; b.textContent=locT>=4?'Visos uždarytos ✓':'Pirmyn ▶';
  }
  $('#locTick').addEventListener('click',function(){ if(locT<4){locT++; renderLocs();} });
  INIT[6]=renderLocs;

  /* ---------- 6 nomenklatūra ---------- */
  var nomF='all';
  function renderNom(){
    var q=($('#nomSearch').value||'').toLowerCase(), rows=0, body='';
    P.forEach(function(p){
      var d=p.c1-p.buh;
      if(nomF==='diff'&&!d) return;
      if(q&&(p.n+' '+p.k+' '+p.e).toLowerCase().indexOf(q)<0) return;
      rows++;
      body+='<tr><td data-label="Kodas"><b>'+esc(p.k)+'</b></td><td data-label="Pavadinimas">'+esc(p.n)+'</td><td data-label="Barkodas" class="ean">'+p.e+'</td>'+
        '<td data-label="Apskaitoje" class="num">'+fmt(p.buh)+' '+p.u+'</td><td data-label="Rasta" class="num">'+fmt(p.c1)+' '+p.u+'</td>'+
        '<td data-label="Skirtumas" class="num '+(d<0?'neg':(d>0?'pos':'zero'))+'">'+sgn(d)+'</td></tr>';
    });
    $('#nomBody').innerHTML=body||'<tr><td colspan="6">Nieko nerasta.</td></tr>';
    $('#nomCount').innerHTML='Rodoma <strong>'+rows+'</strong> iš 10 pavyzdinių prekių (tikroje sistemoje – visos 1200).';
  }
  $('#nomSearch').addEventListener('input',renderNom);
  $$('.seg[data-f]').forEach(function(b){b.addEventListener('click',function(){nomF=b.dataset.f; $$('.seg[data-f]').forEach(function(x){x.setAttribute('aria-pressed',String(x===b));}); renderNom();});});
  INIT[7]=renderNom;

  /* ---------- 7 perpatikrinimas ---------- */
  var s7=0, V=P[0];
  function ph7(){
    var ph=$('#ph7'), btn=$('#ph7Btn'), h=pStatus(), conf=[s7>=3, s7>=5], q2=s7>=4?200:150, tot=200+q2;
    var bar='<div class="p-bar" style="font-size:.85rem"><span class="p-hdr-btn" style="background:#43a047;color:#fff">Lokacijose<br>rasta</span><span>Patikra</span><span class="p-hdr-btn" style="background:#e53935;color:#fff">Perskaičiavimą<br>patvirtinti, grįžti</span></div>';
    function rowsHtml(){return V.locs.map(function(l,i){var q=i===1?q2:l[3];return '<div class="p-lrow'+(conf[i]?' ok':'')+'"><span>Lokacija / Lentyna<br><b>'+l[0]+' / '+l[1]+'</b></span><span style="text-align:right"><b>'+q+' vnt.</b><br>'+(conf[i]?'✓ patvirtinta':'nepatvirtinta')+'</span></div>';}).join('');}
    var card='<div class="p-card"><b>'+esc(V.n)+'</b><br><span class="ean">'+V.e+'</span> · '+V.k+'<br><small>Tikrintojas: <b>Darbuotojas 3</b></small></div>';
    var kv=function(t){var d=t-V.buh;return '<div class="p-kv"><div><b>'+t+'</b>Iš viso</div><div><b>'+V.buh+'</b>Buh.</div><div><b>'+sgn(d)+'</b>Skirt.</div></div>';};
    if(s7===0){ h+=bar+'<div class="p-body"><div class="p-field"><small>Nuskenuokite barkodą</small><b>&nbsp;</b></div><div class="p-card muted">Nuskenuokite prekę, kurią reikia perpatikrinti.</div></div>'; btn.textContent='Nuskenuoti prekę'; }
    else if(s7===1||s7===7){ h+=bar+'<div class="p-body"><div class="p-field"><small>Barkodas</small><b>'+V.e+'</b></div>'+card+kv(s7===7?400:350)+rowsHtml()+(s7===7?'<div class="p-lrow ok" style="justify-content:center"><b>✓ Skirtumo nėra</b></div>':'')+'</div>';
      btn.textContent=s7===7?'Perpatikrinta ✓':'Lokacijose rasta'; btn.disabled=s7===7; }
    else {
      h+=bar+'<div class="p-body"><div class="p-field"><small>Barkodas</small><b>'+V.e+'</b></div>'+card+kv(tot)+'</div>';
      if(s7===2||s7===3||s7===5){ var nconf=conf.filter(Boolean).length;
        h+='<div class="p-dialog"><div class="box" style="text-align:left"><div class="p-ybar" style="background:#2e9d4b;color:#fff;border-radius:10px;margin-bottom:8px">Lokacijose rasta</div><b>'+esc(V.n)+'</b>'+
          '<div class="p-cnt"><div class="c-b"><b>2</b>Iš viso</div><div class="c-g"><b>'+nconf+'</b>Patvirtinta</div><div class="c-o"><b>'+(2-nconf)+'</b>Liko</div></div>'+rowsHtml()+'</div></div>';
        btn.textContent= s7===2?'Patvirtinti 00001 / 1':(s7===3?'Keisti kiekį 00004 / 2':'Perskaičiavimą patvirtinti');
      } else if(s7===4){
        h+='<div class="p-dialog"><div class="box" style="text-align:left;padding:0;overflow:hidden"><div class="p-ybar">KIEKIO KEITIMAS</div><div style="padding:12px"><b>'+esc(V.n)+'</b>'+
          '<div class="p-lrow" style="margin:8px 0">Lokacija / Lentyna <b>00004 / 2</b></div><div class="p-field"><small>Kiekis</small><b>200</b> <small style="display:inline">(buvo 150)</small></div>'+
          '<div class="p-row" style="margin-top:8px"><span class="p-btn p-grn">✓ Patvirtinti</span></div><div class="p-row" style="margin-top:6px"><span class="p-btn p-gry">‹ Grįžti<small>nieko nekeisti</small></span><span class="p-btn p-red">Atšaukti<small>patvirtinimą</small></span></div></div></div></div>';
        btn.textContent='Patvirtinti kiekį 200';
      } else if(s7===6){
        h+='<div class="p-dialog"><div class="box"><h4>Ar norite patvirtinti prekes?</h4><div class="p-lrow ok" style="margin-bottom:6px"><span>✓ <b>Bus patvirtinta</b></span><b>2</b></div><div class="p-lrow" style="margin-bottom:8px;background:#fff4e5"><span>! <b>Liks nepatvirtinta</b></span><b>0</b></div>'+
          '<div class="p-row"><span class="p-btn p-red">Ne<small>atšaukiu patvirtintus</small></span><span class="p-btn p-grn">Taip<small>patvirtinu patvirtintus</small></span></div></div></div>';
        btn.textContent='Taip';
      }
    }
    ph.innerHTML=h;
    var k=s7<=1?0:(s7<=3?1:(s7<=5?2:3)); if(s7===0)k=0;
    $$('#flow7 li').forEach(function(li){var i=+li.dataset.k; li.className=(s7===7||i<k)?'done':(i===k?'cur':'');});
  }
  $('#ph7Btn').addEventListener('click',function(){ if(s7<7){s7++; ph7();} });
  INIT[8]=ph7;

  /* ---------- 8 skirtumų ataskaita ---------- */
  var confirmed=false;
  function sums(){var s=0,p=0;P.forEach(function(x){var v=(x.c2-x.buh)*x.pr; if(v<0)s+=v; else p+=v;});return {s:s,p:p,n:s+p};}
  function renderDiff(){
    var body='';
    P.forEach(function(p){
      if(p.c1===p.buh&&p.c2===p.buh) return;
      var d=p.c2-p.buh, gone=d===0;
      body+='<tr'+(gone?' style="background:#f3f6f8;color:#6a7a88"':'')+'><td data-label="Prekė"><b>'+esc(p.n)+'</b><br><span class="ean">'+p.k+'</span>'+(gone?' <span class="st st-g">Perpatikrinta – skirtumo nėra</span>':'')+'</td>'+
        '<td data-label="Apskaitoje" class="num">'+fmt(p.buh)+'</td><td data-label="Rasta" class="num">'+fmt(p.c2)+(p.c2!==p.c1?' <s class="muted">'+fmt(p.c1)+'</s>':'')+'</td>'+
        '<td data-label="Skirtumas" class="num '+(d<0?'neg':(d>0?'pos':'zero'))+'">'+sgn(d)+'</td><td data-label="Kaina" class="num">'+fmt(p.pr,2)+' €</td>'+
        '<td data-label="Suma" class="num '+(d<0?'neg':(d>0?'pos':'zero'))+'">'+(gone?'0,00 €':eur(d*p.pr))+'</td></tr>';
    });
    $('#diffBody').innerHTML=body;
    var t=sums();
    $('#totals').innerHTML='<span>Trūkumas: <strong class="neg">'+eur(t.s)+'</strong></span><span>Perteklius: <strong class="pos">'+eur(t.p)+'</strong></span><span>Grynasis: <strong>'+eur(t.n)+'</strong></span><span class="muted">Pavyzdiniai skaičiai</span>';
    var st=$('#invState'), b=$('#confirmInv');
    if(confirmed){ st.className='state ok'; st.innerHTML='Būsena: <strong>✓ patvirtinta</strong>'; b.disabled=true; b.textContent='Patvirtinta ✓'; }
    else { st.className='state'; st.innerHTML='Būsena: <strong>vykdoma</strong>'; b.disabled=false; b.textContent='Patvirtinti inventorizaciją'; }
  }
  var lastFocus=null;
  function openModal(){ lastFocus=document.activeElement; $('#modal').hidden=false; $('#mYes').focus(); }
  function closeModal(){ $('#modal').hidden=true; if(lastFocus) lastFocus.focus(); }
  $('#confirmInv').addEventListener('click',openModal);
  $('#mNo').addEventListener('click',closeModal);
  $('#mYes').addEventListener('click',function(){ confirmed=true; $('#modal').hidden=true; renderDiff(); $('#nextBtn').focus(); });
  $('#modal').addEventListener('keydown',function(e){ if(e.key==='Tab'){ var a=$('#mNo'),b=$('#mYes'); if(e.shiftKey&&document.activeElement===a){e.preventDefault();b.focus();} else if(!e.shiftKey&&document.activeElement===b){e.preventDefault();a.focus();} } });
  INIT[9]=renderDiff;

  /* ---------- 9 eksportas ---------- */
  function tbl(head,rows,numCols){
    numCols=numCols||[];
    var h='<table><thead><tr><th class="rn"></th>'+head.map(function(x,i){return '<th'+(numCols.indexOf(i)>=0?' class="num"':'')+'>'+x+'</th>';}).join('')+'</tr></thead><tbody>';
    rows.forEach(function(r,ri){h+='<tr><td class="rn">'+(ri+2)+'</td>'+r.map(function(c,i){return '<td'+(numCols.indexOf(i)>=0?' class="num"':'')+'>'+c+'</td>';}).join('')+'</tr>';});
    return h+'</tbody></table>';
  }
  function diffRows(){return P.filter(function(p){return p.c2!==p.buh;});}
  var SHEETS=[
    function(){return tbl(['Kodas','Kiekis'],P.map(function(p){return [p.k,fmt(p.c2)];}),[1]);},
    function(){return tbl(['Kodas','Pavadinimas','Apskaitoje','Rasta','Skirtumas','Suma, €'],diffRows().map(function(p){var d=p.c2-p.buh;return [p.k,esc(p.n),fmt(p.buh),fmt(p.c2),sgn(d),eur(d*p.pr)];}),[2,3,4,5]);},
    function(){var r=[];P.forEach(function(p){p.locs.forEach(function(l,i){r.push([l[0],l[1],W[l[2]],(p.c1!==p.buh&&RC[l[0]])?RC[l[0]]:'–',p.k,esc(p.n),fmt(p.fin[i])]);});});r.sort(function(a,b){return a[0]<b[0]?-1:(a[0]>b[0]?1:a[1]-b[1]);});
      return tbl(['Lokacija','Lentyna','Skaičiavo','Perpatikrino','Kodas','Pavadinimas','Kiekis'],r,[1,6])+'<p class="tiny" style="padding:6px 10px">Tikrame faile – darbuotojų <strong>vardai ir pavardės</strong>.</p>';},
    function(){var t=sums(),bv=0,fv=0;P.forEach(function(p){bv+=p.buh*p.pr;fv+=p.c2*p.pr;});
      return '<div class="ttl">INVENTORIZACIJOS REZULTATO ATASKAITA</div>'+tbl(['Rodiklis','Reikšmė'],[['Įmonė','UAB Pavyzdys'],['Sandėlis','Kauno sandėlis'],['Data','2026-12-30'],['Apskaitos vertė',fmt(bv,2)+' €'],['Faktinė vertė',fmt(fv,2)+' €'],['Trūkumas',eur(t.s)],['Perteklius',eur(t.p)],['Grynasis skirtumas',eur(t.n)],['Būsena',confirmed?'Patvirtinta':'Nepatvirtinta']],[1])+'<p class="tiny" style="padding:6px 10px">Paruošta <strong>spausdinti buhalterijai</strong>. Pavyzdiniai skaičiai.</p>';}
  ];
  function showSheet(i){ $$('#xlsTabs [role=tab]').forEach(function(b){var on=+b.dataset.sh===i; b.setAttribute('aria-selected',String(on)); b.tabIndex=on?0:-1;}); $('#xlsSheet').innerHTML=SHEETS[i](); $('#xlsSheet').setAttribute('aria-label',$$('#xlsTabs [role=tab]')[i].textContent); }
  $('#xlsTabs').addEventListener('click',function(e){var b=e.target.closest('[role=tab]'); if(b) showSheet(+b.dataset.sh);});
  $('#xlsTabs').addEventListener('keydown',function(e){var tabs=$$('#xlsTabs [role=tab]'),i=tabs.indexOf(document.activeElement); if(i<0)return; var n=e.key==='ArrowRight'?(i+1)%4:(e.key==='ArrowLeft'?(i+3)%4:-1); if(n>=0){e.preventDefault();showSheet(n);tabs[n].focus();}});
  function renderPdf(){var t=sums(); $('#pdfBody').innerHTML='<table><thead><tr><th>Prekė</th><th class="num">Skirt.</th><th class="num">Suma</th></tr></thead><tbody>'+
    diffRows().map(function(p){var d=p.c2-p.buh;return '<tr><td>'+esc(p.n)+'</td><td class="num '+(d<0?'neg':'pos')+'">'+sgn(d)+'</td><td class="num '+(d<0?'neg':'pos')+'">'+eur(d*p.pr)+'</td></tr>';}).join('')+
    '</tbody><tfoot><tr><th>Trūkumas</th><td></td><td class="num neg">'+eur(t.s)+'</td></tr><tr><th>Perteklius</th><td></td><td class="num pos">'+eur(t.p)+'</td></tr><tr><th>Grynasis</th><td></td><td class="num"><b>'+eur(t.n)+'</b></td></tr></tfoot></table>';}
  $('#expBtn').addEventListener('click',function(){ $('#expMsg').innerHTML='✓ Tikroje sistemoje dabar atsisiųstų <strong>Excel</strong> ir <strong>PDF</strong>. Demo failų nekuria.'; });
  INIT[10]=function(){ showSheet(0); renderPdf(); $('#expMsg').textContent=''; };

  /* ---------- 10 kainos ---------- */
  var calc={sc:3,dd:2};
  function renderCalc(){ $('#cSc').textContent=calc.sc; $('#cDd').textContent=calc.dd; $('#cScx').textContent=calc.sc+' × '+calc.dd+' × 40 €'; $('#cSum').textContent=fmt(140+calc.sc*calc.dd*40)+' €'; }
  $$('.stepper button').forEach(function(b){b.addEventListener('click',function(){var k=b.dataset.c; calc[k]=Math.max(k==='sc'?0:1,Math.min(k==='sc'?20:10,calc[k]+(+b.dataset.d))); renderCalc();});});
  INIT[11]=renderCalc;

  function resetAll(){ setTime(1); resetLogin(); resetImp(); s4={st:0,scans:0}; $('#ph4Btn').disabled=false; locT=0; nomF='all'; $('#nomSearch').value=''; $$('.seg[data-f]').forEach(function(x){x.setAttribute('aria-pressed',String(x.dataset.f==='all'));}); s7=0; $('#ph7Btn').disabled=false; confirmed=false; calc={sc:3,dd:2}; }
  resetAll();
  show(fromHash(),false);
})();
