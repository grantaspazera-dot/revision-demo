/* REVISION – interaktyvus demo v3. Visi duomenys išgalvoti. Jokių tinklo užklausų. */
(function(){
  'use strict';
  var $=function(s,r){return (r||document).querySelector(s);};
  var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
  function fmt(n,d){return Number(n).toLocaleString('lt-LT',{minimumFractionDigits:d||0,maximumFractionDigits:d||0});}
  function eur(n){return (n<0?'−':(n>0?'+':''))+fmt(Math.abs(n),2)+' €';}
  function sgn(n){return n===0?'0':(n<0?'−'+fmt(Math.abs(n)):'+'+fmt(n));}
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function ean(body){var s='200'+body,t=0;for(var i=0;i<12;i++){t+=(+s[i])*(i%2?3:1);}return s+((10-t%10)%10);}

  /* ---------- išgalvoti duomenys ---------- */
  var W=['Darbuotojas 1','Darbuotojas 2','Darbuotojas 3','Darbuotojas 4'];
  // locs: [lokacija, lentyna, skaičiavusio darbuotojo nr, kiekis]; fix: perpatikrinimo pataisa; found: rasta tik perpatikrinant
  var P=[
    {k:'VP-0001',n:'Varžtas M8x40 DIN933',u:'vnt.',b:'000100010',buh:400,pr:0.18,locs:[['00001',1,0,200],['00004',2,1,150]],fix:{i:1,q:200}},
    {k:'VP-0002',n:'Veržlė M8 DIN934',u:'vnt.',b:'000100020',buh:1000,pr:0.06,locs:[['00001',2,0,1000]]},
    {k:'VP-0003',n:'Poveržlė M8 DIN125',u:'vnt.',b:'000100030',buh:2000,pr:0.03,locs:[['00002',1,0,1000],['00002',2,0,1000]]},
    {k:'DZ-0101',n:'Dažai balti 10 l',u:'vnt.',b:'000201010',buh:36,pr:32.90,locs:[['00003',1,1,34]]},
    {k:'DZ-0102',n:'Gruntas universalus 5 l',u:'vnt.',b:'000201020',buh:20,pr:14.50,locs:[['00004',1,1,20]]},
    {k:'DZ-0103',n:'Glaistas 5 kg',u:'vnt.',b:'000201030',buh:12,pr:9.90,locs:[],found:['00006',2,12]},
    {k:'SL-0201',n:'Silikonas skaidrus 300 ml',u:'vnt.',b:'000202010',buh:120,pr:4.20,locs:[['00005',1,2,96]],fix:{i:0,q:120}},
    {k:'SL-0202',n:'Montavimo putos 750 ml',u:'vnt.',b:'000202020',buh:48,pr:7.40,locs:[['00006',1,2,45]]},
    {k:'EL-0301',n:'Kabelis NYM 3x1,5',u:'m',b:'000303010',buh:1000,pr:0.65,locs:[['00007',1,3,1100]]},
    {k:'EL-0302',n:'Izoliacinė juosta 19 mm',u:'vnt.',b:'000303020',buh:200,pr:0.95,locs:[['00008',1,3,210]]},
    {k:'EL-0303',n:'Kištukinis lizdas IP44',u:'vnt.',b:'000303030',buh:30,pr:6.85,locs:[['00008',2,3,28]]}
  ];
  // perpatikrina KITAS darbuotojas
  var RC={'00001':'Darbuotojas 3','00003':'Darbuotojas 4','00004':'Darbuotojas 3','00005':'Darbuotojas 1','00006':'Darbuotojas 1','00007':'Darbuotojas 2','00008':'Darbuotojas 2'};
  P.forEach(function(p){
    p.e=ean(p.b);
    p.c1=p.locs.reduce(function(a,l){return a+l[3];},0);
    p.fin=p.locs.map(function(l,i){return (p.fix&&p.fix.i===i)?p.fix.q:l[3];});
    p.c2=p.fin.reduce(function(a,q){return a+q;},0)+(p.found?p.found[2]:0);
    p.who=p.locs.length?W[p.locs[0][2]]:'–';
    p.rcBy=p.found?RC[p.found[0]]:(p.locs.length?RC[p.locs[p.fix?p.fix.i:0][0]]:'');
  });
  var LOCS=['00001','00002','00003','00004','00005','00006','00007','00008'];
  function locWorker(l){for(var i=0;i<P.length;i++){for(var j=0;j<P[i].locs.length;j++){if(P[i].locs[j][0]===l)return W[P[i].locs[j][2]];}}return '';}
  function locQty(l){var q=0;P.forEach(function(p){p.locs.forEach(function(x,i){if(x[0]===l)q+=p.fin[i];}); if(p.found&&p.found[0]===l)q+=p.found[2];});return q;}

  /* ---------- navigacija ---------- */
  var LABELS=['Pradžia','Pasiruošimas','Skaičiavimas','Vadovo vaizdas','Perpatikrinimas','Analizė','Girdime','Programa','Kaina'];
  var STAGE=['','Etapas 1','Etapas 2','Etapas 2','Etapas 3','Etapas 4','','',''];
  var GROUP=[0,1,2,2,3,1,0,0,0];
  var LAST=8, cur=0, screens=$$('.screen');
  var ol=$('#stepsNav ol');
  LABELS.forEach(function(t,i){
    var li=document.createElement('li'); if(GROUP[i]) li.className='g'+GROUP[i];
    li.innerHTML='<button type="button" data-go="'+i+'" aria-label="'+i+'. '+t+'"><span class="n">'+i+'</span><span class="t">'+t+'</span></button>';
    ol.appendChild(li);
  });
  function show(n,focus){
    n=Math.max(0,Math.min(LAST,n)); cur=n;
    screens.forEach(function(s){s.hidden=(+s.dataset.screen!==n);});
    $('#pager').hidden=(n===0);
    $$('#stepsNav button').forEach(function(b){var k=+b.dataset.go; if(k===n)b.setAttribute('aria-current','step'); else b.removeAttribute('aria-current'); b.classList.toggle('done',k<n);});
    $('#pagerPos').textContent=n+' / '+LAST;
    $('#stagePill').textContent=STAGE[n];
    $('#nextBtn').disabled=(n===LAST);
    var hash=n===0?'':'#'+n;
    if(location.hash!==hash) history.replaceState(null,'',hash||location.pathname);
    if(INIT[n]) INIT[n]();
    window.scrollTo(0,0);
    if(focus!==false){var h=$('h1,h2',screens[n]); if(h) h.focus({preventScroll:true});}
  }
  $$('[data-screen="0"] [data-go]').forEach(function(b){b.addEventListener('click',function(){show(+b.dataset.go);});});
  $('#prevBtn').addEventListener('click',function(){show(cur-1);});
  $('#nextBtn').addEventListener('click',function(){show(cur+1);});
  $('#restartBtn').addEventListener('click',function(){resetAll();show(0);});
  $('#stepsNav').addEventListener('click',function(e){var b=e.target.closest('button[data-go]'); if(b) show(+b.dataset.go);});
  document.addEventListener('keydown',function(e){
    if(e.altKey||e.ctrlKey||e.metaKey) return;
    var t=e.target.tagName; if(t==='INPUT'||t==='TEXTAREA'||t==='SELECT') return;
    if(!$('#modal').hidden){ if(e.key==='Escape') closeModal(); return; }
    if(e.target.getAttribute('role')==='tab') return;
    if(e.key==='ArrowRight') show(cur+1); else if(e.key==='ArrowLeft') show(cur-1);
  });
  function fromHash(){var n=parseInt(location.hash.replace('#',''),10);return (n>=0&&n<=LAST)?n:0;}
  window.addEventListener('hashchange',function(){show(fromHash());});
  var INIT={};


  /* ---------- 3 vadovo vaizdas (gyvai) ---------- */
  var LW={}; P.forEach(function(p){p.locs.forEach(function(l){LW[l[0]]=l[2];});});
  var Q=[[],[],[],[]];
  function nRows(l){var n=0;P.forEach(function(p){p.locs.forEach(function(x){if(x[0]===l)n++;});});return n;}
  LOCS.slice().sort(function(x,y){return (nRows(y)-nRows(x))||(x<y?-1:1);}).forEach(function(l){P.forEach(function(p){p.locs.forEach(function(x){if(x[0]===l)Q[LW[l]].push({l:l,sh:x[1],p:p,q:x[3]});});});});
  var EV=[]; (function(){var i=0,left=true;while(left){left=false;for(var w=0;w<4;w++){if(Q[w][i]){EV.push(Q[w][i]);left=true;}}i++;}})();
  var TOT=EV.length, mg={k:0,rc:false};
  function locRows(l){return EV.filter(function(e){return e.l===l;}).length;}
  function locDone(l){return EV.slice(0,mg.k).filter(function(e){return e.l===l;}).length;}
  var MS={w:['Laukia','st-x'],c:['Skaičiuojama','st-y'],d:['Baigta','st-g'],r:['Perpatikrinta','st-r']};
  function locSt(l){var d=locDone(l),n=locRows(l); if(!d)return 'w'; if(d<n)return 'c'; return (mg.rc&&RC[l])?'r':'d';}
  function renderMgr(){
    var cnt={w:0,c:0,d:0,r:0}, body='';
    LOCS.forEach(function(l){var st=locSt(l); cnt[st]++;
      body+='<tr'+(mg.last&&mg.last.l===l?' class="row-new"':'')+'><td data-label="Lokacija"><b>'+l+'</b></td><td data-label="Skaičiuoja">'+W[LW[l]]+(st==='r'?'<br><small class="muted">perpatikrino: <strong>'+RC[l]+'</strong></small>':'')+'</td>'+
        '<td data-label="Būsena"><span class="st '+MS[st][1]+'">'+MS[st][0]+'</span></td><td data-label="Eilučių" class="num">'+locDone(l)+' / '+locRows(l)+'</td></tr>';});
    $('#mgrBody').innerHTML=body;
    $('#mgrTiles').innerHTML=['w','c','d','r'].map(function(k){return '<div class="t-'+k+'"><b>'+cnt[k]+'</b>'+MS[k][0]+'</div>';}).join('');
    var pct=Math.round(mg.k/TOT*100); $('#progPct').textContent=pct+' %'; $('#progBar').style.width=pct+'%';
    var e=mg.last, b=$('#scanBtn');
    $('#miniPhone').innerHTML= e?'<div class="mp-h"><b>'+e.l+'</b> · '+W[LW[e.l]]+'</div><div class="mp-b"><span class="ean">'+e.p.e+'</span><b>'+esc(e.p.n)+'</b><span>Lentyna '+e.sh+'</span><strong>'+fmt(e.q)+' '+e.p.u+'</strong></div>'
      :(mg.rc?'':'<div class="mp-h">Skeneris</div><div class="mp-b"><b>Skenuokite barkodą</b><span class="muted">Spauskite mygtuką žemiau</span></div>');
    if(mg.rc){ $('#miniPhone').innerHTML='<div class="mp-h">Perpatikrinimas</div><div class="mp-b"><b>✓ Perpatikrino kiti darbuotojai</b><span>Lokacijos be skirtumų – <strong>Baigta</strong></span></div>'; }
    if(mg.k<TOT){ b.textContent='Nuskenuoti prekę ('+(mg.k+1)+'/'+TOT+')'; b.disabled=false; }
    else if(!mg.rc){ b.textContent='Perpatikrinti skirtumus'; b.disabled=false; }
    else { b.textContent='Baigta ✓'; b.disabled=true; }
  }
  $('#scanBtn').addEventListener('click',function(){ if(mg.k<TOT){mg.last=EV[mg.k];mg.k++;} else {mg.rc=true;mg.last=null;} renderMgr(); });
  function resetMgr(){ mg={k:0,rc:false,last:null}; }
  INIT[3]=renderMgr;

  /* ---------- 4 perpatikrinimas: didžiausi pirmiausia, aiški eilė ---------- */
  var TYPES={per:['Perteklius','st-b',1],nes:['Nesuskaičiuota','st-y',2],tru:['Trūkumas','st-x',3]};
  function firstDiffs(){
    return P.filter(function(p){return p.c1!==p.buh;}).map(function(p){
      var d=p.c1-p.buh; return {p:p,d:d,v:d*p.pr,t:p.c1===0?'nes':(d>0?'per':'tru')};
    });
  }
  var rcO='code';
  function renderRc(){
    var r=firstDiffs();
    if(rcO==='big') r.sort(function(a,b){return Math.abs(b.v)-Math.abs(a.v);});
    if(rcO==='order') r.sort(function(a,b){return (TYPES[a.t][2]-TYPES[b.t][2])||(Math.abs(b.v)-Math.abs(a.v));});
    $('#rcBody').innerHTML=r.map(function(x,i){var T=TYPES[x.t], cls=x.d<0?'neg':'pos';
      return '<tr><td data-label="Prekė">'+(rcO!=='code'?'<span class="rk">'+(i+1)+'</span> ':'')+'<b>'+esc(x.p.n)+'</b></td>'+
        '<td data-label="Tipas"><span class="st '+T[1]+'">'+T[0]+'</span></td>'+
        '<td data-label="Skirtumas" class="num '+cls+'">'+sgn(x.d)+' '+x.p.u+'</td>'+
        '<td data-label="Vertė" class="num '+cls+'">'+eur(x.v)+'</td>'+
        '<td data-label="Skaičiavo">'+x.p.who+'</td><td data-label="Tikrina"><strong>'+x.p.rcBy+'</strong></td></tr>';}).join('');
    $('#rcNote').innerHTML= rcO==='code'?'Paspauskite <strong>„Didžiausi“</strong>, tada <strong>„Tikrinimo eilė“</strong>.':
      (rcO==='big'?'<strong>Didžiausi skirtumai</strong> – viršuje. Pradedame nuo jų.':'<strong>1</strong> perteklius → <strong>2</strong> nesuskaičiuota → <strong>3</strong> trūkumai. Grupėje – didžiausi pirmiausia.');
    $$('.seg[data-o]').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.o===rcO));});
  }
  $$('.seg[data-o]').forEach(function(b){b.addEventListener('click',function(){rcO=b.dataset.o; renderRc();});});
  INIT[4]=function(){renderRcKpi();renderRc();};
  /* ---------- skirtumų statistika ---------- */
  function stat(first){
    var r={n:P.length,d:0,per:{c:0,v:0},tru:{c:0,v:0},nes:{c:0,v:0}};
    P.forEach(function(p){var q=first?p.c1:p.c2, d=q-p.buh, v=d*p.pr; if(!d)return; r.d++;
      if(d>0){r.per.c++;r.per.v+=v;} else {r.tru.c++;r.tru.v+=v; if(q===0){r.nes.c++;r.nes.v+=v;}}});
    r.net=r.per.v+r.tru.v; r.pct=Math.round(r.d/r.n*100); return r;
  }
  function kpi(cls,big,lbl,sub){return '<div class="kpi '+cls+'"><b>'+big+'</b><span>'+lbl+'</span>'+(sub?'<small>'+sub+'</small>':'')+'</div>';}
  function renderRcKpi(){var a=stat(true);
    $('#rcKpi').innerHTML=kpi('',a.d,'skirtumų iš '+a.n,a.pct+' % eilučių')+
      kpi('per',a.per.c,'perteklius',eur(a.per.v))+kpi('nes',a.nes.c,'nesuskaičiuota',eur(a.nes.v))+kpi('tru',a.tru.c-a.nes.c,'trūkumai',eur(a.tru.v-a.nes.v));}
  function renderStats(){
    var a=stat(true), b=stat(false);
    $('#stKpi').innerHTML=
      kpi('',a.d+' → '+b.d,'eilučių su skirtumu',a.pct+' % → '+b.pct+' %')+
      kpi('tru',eur(b.tru.v),'trūkumas po perpatikrinimo','buvo '+eur(a.tru.v))+
      kpi('per',eur(b.per.v),'perteklius po perpatikrinimo','buvo '+eur(a.per.v))+
      kpi('net',eur(b.net),'grynasis skirtumas','buvo '+eur(a.net));
    var mx=Math.max(Math.abs(a.tru.v),Math.abs(a.per.v),Math.abs(b.tru.v),Math.abs(b.per.v));
    function bar(lbl,cls,v,c){var w=Math.max(2,Math.round(Math.abs(v)/mx*100));return '<div class="bar-row"><span class="bl">'+lbl+'</span><span class="bt"><i class="'+cls+'" style="width:'+w+'%"></i></span><span class="bv">'+eur(v)+' <small>('+c+' eil.)</small></span></div>';}
    $('#stBars').innerHTML=
      '<p class="bg-t"><strong>Trūkumas</strong></p>'+bar('Prieš','tru o',a.tru.v,a.tru.c)+bar('Po','tru',b.tru.v,b.tru.c)+
      '<p class="bg-t"><strong>Perteklius</strong></p>'+bar('Prieš','per o',a.per.v,a.per.c)+bar('Po','per',b.per.v,b.per.c)+
      '<p class="muted small">Perpatikrinus <strong>'+(a.d-b.d)+'</strong> skirtumai pasirodė <strong>skaičiavimo klaidos</strong>.</p>';
    var top=P.filter(function(p){return p.c2!==p.buh;}).map(function(p){return {p:p,d:p.c2-p.buh,v:(p.c2-p.buh)*p.pr};}).sort(function(x,y){return Math.abs(y.v)-Math.abs(x.v);}).slice(0,3);
    $('#stTop').innerHTML=top.map(function(x){var c=x.v<0?'neg':'pos';return '<li><span><b>'+esc(x.p.n)+'</b><br><small class="muted">'+sgn(x.d)+' '+x.p.u+'</small></span><b class="'+c+'">'+eur(x.v)+'</b></li>';}).join('');
  }
  INIT[5]=renderStats;


  /* ---------- 6 programa: skirtukai ---------- */
  var pt=0;
  function showTab(i){
    pt=i;
    $$('#progTabs [role=tab]').forEach(function(b){var on=+b.dataset.pt===i; b.setAttribute('aria-selected',String(on)); b.tabIndex=on?0:-1;});
    $$('.ppanel').forEach(function(p,k){p.hidden=k!==i;});
    [renderPhone,renderLocs,renderNom,renderDiff,function(){showSheet(0);renderPdf();}][i]();
  }
  $('#progTabs').addEventListener('click',function(e){var b=e.target.closest('[role=tab]'); if(b) showTab(+b.dataset.pt);});
  $('#progTabs').addEventListener('keydown',function(e){var n=e.key==='ArrowRight'?(pt+1)%5:(e.key==='ArrowLeft'?(pt+4)%5:-1); if(n>=0){e.preventDefault();showTab(n);$('#pt'+n).focus();}});
  INIT[7]=function(){showTab(pt);};

  function pStatus(){return '<div class="p-status"><span>09:41</span><span>4G ▮ 87%</span></div>';}
  function renderPhone(){
    var p=P[2];
    $('#phone').innerHTML=pStatus()+'<div class="p-bar"><span>00002<small>Darbuotojas 1</small></span><span class="p-hdr-btn">🔒 Uždaryti<br>lokaciją</span></div><div class="p-body">'+
      '<div class="p-row"><span class="p-btn p-red">−</span><span class="p-btn" style="background:#fff">Lentyna <b>2</b></span><span class="p-btn p-grn">+</span></div>'+
      '<div class="p-field"><small>Skenuokite barkodą</small><b>'+p.e+'</b></div>'+
      '<div class="p-row"><span class="p-btn p-lgr">+1<small>po 1</small></span><span class="p-btn p-gry">123<small>Kiekis</small></span></div>'+
      '<div class="p-sum"><div><b>2</b>Eilučių</div><div><b>1</b>Prekių</div><div><b>2 000</b>Kiekis</div><div><b>2</b>Lentynų</div></div>'+
      [2,1].map(function(sh){return '<div class="p-item"><div><span class="ean">'+p.e+'</span> '+esc(p.k)+'<br>'+esc(p.n)+'<br>Lentyna: '+sh+'</div><b class="q">1 000</b></div>';}).join('')+'</div>';
  }
  function renderLocs(){
    var body='';
    LOCS.forEach(function(l){
      body+='<tr><td data-label="Lokacija"><b>'+l+'</b></td><td data-label="1 skaičiavimas">'+locWorker(l)+'</td>'+
        '<td data-label="Perpatikrinimas">'+(RC[l]?'<strong>'+RC[l]+'</strong>':'<span class="muted">nereikia</span>')+'</td>'+
        '<td data-label="Būsena"><span class="st st-g">Uždaryta</span></td><td data-label="Kiekis" class="num">'+fmt(locQty(l))+'</td></tr>';
    });
    $('#locBody').innerHTML=body;
    $('#locTiles').innerHTML='<div class="tb"><b>0</b>Nepradėtos</div><div class="ty"><b>0</b>Pradėtos</div><div class="tg"><b>8</b>Uždarytos</div><div class="tx"><b>0</b>Laisvos</div>';
  }
  function renderNom(){
    var q=($('#nomSearch').value||'').toLowerCase(), body='';
    P.forEach(function(p){
      if(q&&(p.n+' '+p.k+' '+p.e).toLowerCase().indexOf(q)<0) return;
      var d=p.c2-p.buh;
      body+='<tr><td data-label="Kodas"><b>'+esc(p.k)+'</b></td><td data-label="Pavadinimas">'+esc(p.n)+'</td><td data-label="Barkodas" class="ean">'+p.e+'</td>'+
        '<td data-label="Apskaitoje" class="num">'+fmt(p.buh)+' '+p.u+'</td><td data-label="Rasta" class="num">'+fmt(p.c2)+' '+p.u+'</td>'+
        '<td data-label="Skirtumas" class="num '+(d<0?'neg':(d>0?'pos':'zero'))+'">'+sgn(d)+'</td></tr>';
    });
    $('#nomBody').innerHTML=body||'<tr><td colspan="6">Nieko nerasta.</td></tr>';
  }
  $('#nomSearch').addEventListener('input',renderNom);

  var confirmed=false;
  function sums(){var s=0,p=0;P.forEach(function(x){var v=(x.c2-x.buh)*x.pr; if(v<0)s+=v; else p+=v;});return {s:s,p:p,n:s+p};}
  function diffRows(){return P.filter(function(p){return p.c2!==p.buh;});}
  function renderDiff(){
    $('#diffBody').innerHTML=diffRows().map(function(p){var d=p.c2-p.buh, c=d<0?'neg':'pos';
      return '<tr><td data-label="Prekė"><b>'+esc(p.n)+'</b><br><span class="ean">'+p.k+'</span></td><td data-label="Apskaitoje" class="num">'+fmt(p.buh)+'</td><td data-label="Rasta" class="num">'+fmt(p.c2)+'</td>'+
        '<td data-label="Skirtumas" class="num '+c+'">'+sgn(d)+'</td><td data-label="Suma" class="num '+c+'">'+eur(d*p.pr)+'</td></tr>';}).join('');
    var t=sums();
    $('#totals').innerHTML='<span>Trūkumas: <strong class="neg">'+eur(t.s)+'</strong></span><span>Perteklius: <strong class="pos">'+eur(t.p)+'</strong></span><span>Grynasis: <strong>'+eur(t.n)+'</strong></span>';
    var st=$('#invState'), b=$('#confirmInv');
    if(confirmed){ st.className='state ok'; st.innerHTML='Būsena: <strong>✓ patvirtinta</strong>'; b.disabled=true; b.textContent='Patvirtinta ✓'; }
    else { st.className='state'; st.innerHTML='Būsena: <strong>vykdoma</strong>'; b.disabled=false; b.textContent='Patvirtinti inventorizaciją'; }
  }
  var lastFocus=null;
  function openModal(){ lastFocus=document.activeElement; $('#modal').hidden=false; $('#mYes').focus(); }
  function closeModal(){ $('#modal').hidden=true; if(lastFocus) lastFocus.focus(); }
  $('#confirmInv').addEventListener('click',openModal);
  $('#mNo').addEventListener('click',closeModal);
  $('#mYes').addEventListener('click',function(){ confirmed=true; $('#modal').hidden=true; renderDiff(); $('#pt3').focus(); });
  $('#modal').addEventListener('keydown',function(e){ if(e.key==='Tab'){ var a=$('#mNo'),b=$('#mYes'); if(e.shiftKey&&document.activeElement===a){e.preventDefault();b.focus();} else if(!e.shiftKey&&document.activeElement===b){e.preventDefault();a.focus();} } });

  function tbl(head,rows,numCols){
    numCols=numCols||[];
    var h='<table><thead><tr><th class="rn"></th>'+head.map(function(x,i){return '<th'+(numCols.indexOf(i)>=0?' class="num"':'')+'>'+x+'</th>';}).join('')+'</tr></thead><tbody>';
    rows.forEach(function(r,ri){h+='<tr><td class="rn">'+(ri+2)+'</td>'+r.map(function(c,i){return '<td'+(numCols.indexOf(i)>=0?' class="num"':'')+'>'+c+'</td>';}).join('')+'</tr>';});
    return h+'</tbody></table>';
  }
  var SHEETS=[
    function(){return tbl(['Kodas','Kiekis'],P.map(function(p){return [p.k,fmt(p.c2)];}),[1]);},
    function(){return tbl(['Kodas','Pavadinimas','Apskaitoje','Rasta','Skirtumas','Suma, €'],diffRows().map(function(p){var d=p.c2-p.buh;return [p.k,esc(p.n),fmt(p.buh),fmt(p.c2),sgn(d),eur(d*p.pr)];}),[2,3,4,5]);},
    function(){var r=[];P.forEach(function(p){var bad=p.c1!==p.buh;
        p.locs.forEach(function(l,i){r.push([l[0],l[1],W[l[2]],(bad&&RC[l[0]])?RC[l[0]]:'–',p.k,esc(p.n),fmt(p.fin[i])]);});
        if(p.found) r.push([p.found[0],p.found[1],'–',RC[p.found[0]],p.k,esc(p.n),fmt(p.found[2])]);});
      r.sort(function(a,b){return a[0]<b[0]?-1:(a[0]>b[0]?1:a[1]-b[1]);});
      return tbl(['Lokacija','Lentyna','Skaičiavo','Perpatikrino','Kodas','Pavadinimas','Kiekis'],r,[1,6])+'<p class="tiny" style="padding:6px 10px">Tikrame faile – darbuotojų <strong>vardai ir pavardės</strong>.</p>';},
    function(){var t=sums(),bv=0,fv=0;P.forEach(function(p){bv+=p.buh*p.pr;fv+=p.c2*p.pr;});
      return '<div class="ttl">INVENTORIZACIJOS REZULTATO ATASKAITA</div>'+tbl(['Rodiklis','Reikšmė'],[['Įmonė','UAB Pavyzdys'],['Sandėlis','Kauno sandėlis'],['Data','2026-12-30'],['Apskaitos vertė',fmt(bv,2)+' €'],['Faktinė vertė',fmt(fv,2)+' €'],['Trūkumas',eur(t.s)],['Perteklius',eur(t.p)],['Grynasis skirtumas',eur(t.n)],['Būsena',confirmed?'Patvirtinta':'Nepatvirtinta']],[1]);}
  ];
  function showSheet(i){ $$('#xlsTabs [role=tab]').forEach(function(b){var on=+b.dataset.sh===i; b.setAttribute('aria-selected',String(on)); b.tabIndex=on?0:-1;}); $('#xlsSheet').innerHTML=SHEETS[i](); $('#xlsSheet').setAttribute('aria-label',$$('#xlsTabs [role=tab]')[i].textContent); }
  $('#xlsTabs').addEventListener('click',function(e){var b=e.target.closest('[role=tab]'); if(b) showSheet(+b.dataset.sh);});
  $('#xlsTabs').addEventListener('keydown',function(e){var tabs=$$('#xlsTabs [role=tab]'),i=tabs.indexOf(document.activeElement); if(i<0)return; var n=e.key==='ArrowRight'?(i+1)%4:(e.key==='ArrowLeft'?(i+3)%4:-1); if(n>=0){e.preventDefault();showSheet(n);tabs[n].focus();}});
  function renderPdf(){var t=sums(); $('#pdfBody').innerHTML='<table><thead><tr><th>Prekė</th><th class="num">Skirt.</th><th class="num">Suma</th></tr></thead><tbody>'+
    diffRows().map(function(p){var d=p.c2-p.buh;return '<tr><td>'+esc(p.n)+'</td><td class="num '+(d<0?'neg':'pos')+'">'+sgn(d)+'</td><td class="num '+(d<0?'neg':'pos')+'">'+eur(d*p.pr)+'</td></tr>';}).join('')+
    '</tbody><tfoot><tr><th>Trūkumas</th><td></td><td class="num neg">'+eur(t.s)+'</td></tr><tr><th>Perteklius</th><td></td><td class="num pos">'+eur(t.p)+'</td></tr><tr><th>Grynasis</th><td></td><td class="num"><b>'+eur(t.n)+'</b></td></tr></tfoot></table>';}

  /* ---------- 7 kaina ---------- */
  var calc={sc:3,dd:2};
  function renderCalc(){ var rent=calc.sc*calc.dd*40;
    $('#cSc').textContent=calc.sc; $('#cDd').textContent=calc.dd;
    $('#cScx').textContent=calc.sc+' × '+calc.dd+' d. × 40 €'; $('#cRent').textContent=fmt(rent)+' €';
    $('#cSum').textContent=fmt(140+rent)+' €'; }
  $$('.stepper button').forEach(function(b){b.addEventListener('click',function(){var k=b.dataset.c; calc[k]=Math.max(k==='sc'?0:1,Math.min(k==='sc'?20:10,calc[k]+(+b.dataset.d))); renderCalc();});});
  INIT[8]=renderCalc;

  function resetAll(){ resetMgr(); rcO='code'; pt=0; $('#nomSearch').value=''; confirmed=false; calc={sc:3,dd:2}; }
  resetAll();
  show(fromHash(),false);
})();
