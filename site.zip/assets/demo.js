/* REVISION – inventorizacijos demo. Visi duomenys išgalvoti. Jokių tinklo užklausų. */
(function(){
  'use strict';
  var $ = function(s,r){return (r||document).querySelector(s);};
  var $$ = function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fmt = function(n,d){return n.toLocaleString('lt-LT',{minimumFractionDigits:d||0,maximumFractionDigits:d||0});};
  var eur = function(n){return (n<0?'−':'+')+fmt(Math.abs(n),2)+' €';};
  var sgn = function(n){return n===0?'0':(n<0?'−'+Math.abs(n):'+'+n);};

  // Fake EAN-13 (prefix 200 = vidinis/nekomercinis), su teisingu kontroliniu skaitmeniu
  function ean(body){var s='200'+body,t=0;for(var i=0;i<12;i++){t+=(+s[i])*(i%2?3:1);}return s+((10-t%10)%10);}

  var products = [
    {n:'Varžtas M8x40 DIN933',e:ean('000108401'),l:'A-01-02',q:50,u:'vnt.'},
    {n:'Veržlė M8 DIN934',e:ean('000109341'),l:'A-01-03',q:100,u:'vnt.'},
    {n:'Poveržlė M8 DIN125',e:ean('000101251'),l:'A-01-04',q:200,u:'vnt.'},
    {n:'Savisriegis 4,2x16',e:ean('000104216'),l:'A-02-01',q:500,u:'vnt.'},
    {n:'Dažai balti 10 l',e:ean('000201010'),l:'B-02-01',q:12,u:'vnt.'},
    {n:'Gruntas universalus 5 l',e:ean('000202005'),l:'B-02-03',q:8,u:'vnt.'},
    {n:'Silikonas skaidrus 300 ml',e:ean('000203300'),l:'B-01-05',q:24,u:'vnt.'},
    {n:'Montavimo putos 750 ml',e:ean('000204750'),l:'B-01-02',q:12,u:'vnt.'},
    {n:'Kabelis NYM 3x1,5 (100 m)',e:ean('000301315'),l:'C-03-01',q:4,u:'ritės'},
    {n:'Kabelis NYM 5x2,5 (50 m)',e:ean('000302525'),l:'C-03-02',q:3,u:'ritės'},
    {n:'Izoliacinė juosta 19 mm',e:ean('000303019'),l:'C-01-04',q:40,u:'vnt.'},
    {n:'Kištukinis lizdas IP44',e:ean('000304044'),l:'C-02-02',q:10,u:'vnt.'}
  ];

  // Neatitikimai: sys = apskaitoje, c1 = 1 skaičiavimas, c2 = perskaičiavimas, kaina EUR
  var diffs = [
    {n:'Varžtas M8x40 DIN933',l:'A-01-02',sys:400,c1:350,c2:400,p:0.18,why:'Rasta neatidaryta dėžė (50 vnt.)'},
    {n:'Dažai balti 10 l',l:'B-02-01',sys:36,c1:34,c2:34,p:32.90,why:'Skirtumas patvirtintas'},
    {n:'Kabelis NYM 3x1,5 (100 m)',l:'C-03-01',sys:10,c1:11,c2:11,p:64.50,why:'Skirtumas patvirtintas'},
    {n:'Silikonas skaidrus 300 ml',l:'B-01-05',sys:120,c1:96,c2:120,p:4.20,why:'Dalis prekių rasta vietoje B-01-06'},
    {n:'Montavimo putos 750 ml',l:'B-01-02',sys:48,c1:45,c2:45,p:7.40,why:'Skirtumas patvirtintas'},
    {n:'Izoliacinė juosta 19 mm',l:'C-01-04',sys:200,c1:210,c2:210,p:0.95,why:'Skirtumas patvirtintas'},
    {n:'Kištukinis lizdas IP44',l:'C-02-02',sys:30,c1:28,c2:28,p:6.85,why:'Skirtumas patvirtintas'}
  ];

  var state = {screen:0, imported:false, scans:0, pos:0, qty:0, role:1, planTick:0, recounted:{}};
  var timers = [];
  function clearTimers(){timers.forEach(clearInterval);timers=[];}

  /* ---------- navigation ---------- */
  var screens = $$('.screen');
  var top = $('.top'), pager = $('#pager');
  function show(n, focus){
    n = Math.max(0, Math.min(6, n));
    clearTimers();
    state.screen = n;
    screens.forEach(function(s){ s.hidden = (+s.dataset.screen !== n); });
    top.classList.toggle('is-intro', n===0 || n===6);
    pager.hidden = (n===0 || n===6);
    $$('#stepsNav button').forEach(function(b){
      var k = +b.dataset.go;
      if(k===n){ b.setAttribute('aria-current','step'); } else { b.removeAttribute('aria-current'); }
      b.classList.toggle('done', k<n);
    });
    $('#pagerPos').textContent = n + ' / 5';
    $('#prevBtn').disabled = false;
    $('#nextBtn').textContent = n===5 ? 'Baigti →' : 'Toliau →';
    var hash = n===0 ? '' : (n===6 ? '#pabaiga' : '#' + n);
    if(location.hash !== hash){ history.replaceState(null,'',hash || location.pathname); }
    if(n===3) renderPlan();
    if(n===4) renderDiffs();
    if(n===5) renderReport();
    window.scrollTo(0,0);
    if(focus!==false){ var h = $('h1,h2', screens[n]); if(h) h.focus({preventScroll:true}); }
  }
  $('#startBtn').addEventListener('click', function(){ show(1); });
  $('#restartBtn').addEventListener('click', function(){ reset(); show(0); });
  $('#prevBtn').addEventListener('click', function(){ show(state.screen-1); });
  $('#nextBtn').addEventListener('click', function(){ show(state.screen+1); });
  $$('#stepsNav button').forEach(function(b){ b.addEventListener('click', function(){ show(+b.dataset.go); }); });
  document.addEventListener('keydown', function(e){
    if(e.altKey||e.ctrlKey||e.metaKey) return;
    var t = e.target.tagName;
    if(t==='INPUT'||t==='TEXTAREA'||t==='SELECT') return;
    if(state.screen<1||state.screen>5) return;
    if(e.key==='ArrowRight'){ show(state.screen+1); }
    else if(e.key==='ArrowLeft'){ show(state.screen-1); }
  });
  function fromHash(){
    var h = location.hash.replace('#','');
    if(h==='pabaiga') return 6;
    var n = parseInt(h,10); return (n>=1&&n<=5)?n:0;
  }
  window.addEventListener('hashchange', function(){ show(fromHash()); });

  function reset(){
    state.imported=false; state.scans=0; state.pos=0; state.qty=0; state.planTick=0; state.recounted={};
    setRole(1);
    var bar=$('#impBar'); bar.setAttribute('aria-valuenow','0'); $('span',bar).style.width='0';
    $('#impCount').textContent='0'; $('#impStatus').textContent='Dar neįkelta'; $('#impStatus').className='';
    $('#impBtn').disabled=false; $('#impBtn').textContent='Įkelti likučius iš ERP';
    $('.app-bar .chip').textContent='Juodraštis'; $('.app-bar .chip').className='chip';
    $('#hint1').className='hint'; $('#hint1').innerHTML='Paspauskite <strong>„Įkelti likučius iš ERP“</strong>.';
    $('#phList').innerHTML=''; $('#phLast').innerHTML='<p class="empty">Paspauskite „Skenuoti“</p>';
    $('#phPos').textContent='0'; $('#phQty').textContent='0'; $('#scanCount').textContent='0'; $('#phLoc').textContent='A-01-02'; $('#phZone').textContent='A';
    $('#hint2').className='hint'; $('#hint2').innerHTML='Nuskenuota: <b id="scanCount">0</b>. Pabandykite bent 3 kartus.';
  }

  /* ---------- step 1: import ---------- */
  $('#impBtn').addEventListener('click', function(){
    if(state.imported) return;
    var btn=this; btn.disabled=true; btn.textContent='Įkeliama…';
    $('#impStatus').textContent='Įkeliama iš ERP…';
    var v=0, bar=$('#impBar');
    function done(){
      state.imported=true;
      $('#impStatus').textContent='Įkelta: 1200 SKU'; $('#impStatus').className='ok';
      btn.textContent='Likučiai įkelti ✓';
      $('.app-bar .chip').textContent='Paruošta'; $('.app-bar .chip').className='chip ok';
      $('#hint1').className='hint ok'; $('#hint1').innerHTML='Puiku – inventorizacija paruošta. Spauskite <strong>„Toliau“</strong>.';
    }
    if(reduce){ v=1200; $('span',bar).style.width='100%'; bar.setAttribute('aria-valuenow','1200'); $('#impCount').textContent='1200'; done(); return; }
    var id=setInterval(function(){
      v=Math.min(1200, v+60+Math.round(Math.random()*40));
      $('span',bar).style.width=(v/12)+'%'; bar.setAttribute('aria-valuenow',v); $('#impCount').textContent=v;
      if(v>=1200){ clearInterval(id); done(); }
    },70);
    timers.push(id);
  });

  /* ---------- step 2: scanning ---------- */
  function setRole(r){
    state.role=r;
    $$('.seg').forEach(function(b){ b.setAttribute('aria-pressed', String(+b.dataset.role===r)); });
    $('#phRole').textContent='Skaičiuotojas '+r;
  }
  $$('.seg').forEach(function(b){ b.addEventListener('click', function(){ setRole(+b.dataset.role); }); });
  $('#scanBtn').addEventListener('click', function(){
    var p = products[state.scans % products.length];
    state.scans++; state.pos++; state.qty += p.q;
    var btn=this; btn.classList.remove('go'); void btn.offsetWidth; btn.classList.add('go');
    $('#phZone').textContent=p.l.charAt(0); $('#phLoc').textContent=p.l;
    var last=$('#phLast');
    last.innerHTML='<div class="nm"></div><div class="ean"></div><div class="q"></div>';
    $('.nm',last).textContent=p.n; $('.ean',last).textContent='EAN '+p.e;
    $('.q',last).textContent='+'+p.q+' '+p.u;
    last.classList.remove('flash'); void last.offsetWidth; last.classList.add('flash');
    var li=document.createElement('li');
    var a=document.createElement('span'); a.textContent=p.l+' · '+p.n;
    var b=document.createElement('b'); b.textContent=p.q+' '+p.u;
    li.appendChild(a); li.appendChild(b);
    var list=$('#phList'); list.insertBefore(li, list.firstChild);
    while(list.children.length>4) list.removeChild(list.lastChild);
    $('#phPos').textContent=fmt(state.pos); $('#phQty').textContent=fmt(state.qty);
    var h=$('#hint2');
    if(state.scans>=3){ h.className='hint ok'; h.innerHTML='Nuskenuota: <b id="scanCount">'+state.scans+'</b>. Matote – jokio rašymo ranka. Spauskite <strong>„Toliau“</strong>.'; }
    else { h.innerHTML='Nuskenuota: <b id="scanCount">'+state.scans+'</b>. Pabandykite bent 3 kartus.'; }
  });

  /* ---------- step 3: plan ---------- */
  var zones=['A','B','C'], RACKS=8, TICKS=12;
  // kiekvienam „tick“ – kiek lentynų kiekvienoje zonoje baigta (A greičiausia, C lėčiausia)
  function zoneDone(z,t){ var speed=[1,0.8,0.68][z]; return Math.min(RACKS, Math.floor(t*speed*RACKS/ (TICKS*0.68) + 0.0001)); }
  function renderPlan(){
    var plan=$('#plan'), prog=$('#zoneProg');
    if(!plan.children.length){
      zones.forEach(function(z){
        var d=document.createElement('div'); d.className='zone'; d.id='zone'+z;
        var h=document.createElement('h4'); h.innerHTML='Zona '+z+' <span id="zp'+z+'">0 %</span>';
        var r=document.createElement('div'); r.className='racks';
        for(var i=1;i<=RACKS;i++){ var c=document.createElement('div'); c.className='rack'; c.textContent=z+'-0'+i; r.appendChild(c); }
        d.appendChild(h); d.appendChild(r); plan.appendChild(d);
        var li=document.createElement('li');
        li.innerHTML='<div class="zl"><span>Zona '+z+(z==='C'?' · Skaičiuotojas 2':(z==='A'?' · Skaičiuotojas 1':' · abu'))+'</span><span id="zq'+z+'">0 %</span></div><div class="bar"><span id="zb'+z+'"></span></div>';
        prog.appendChild(li);
      });
    }
    paintPlan();
  }
  function paintPlan(){
    var t=state.planTick, tot=0;
    zones.forEach(function(z,zi){
      var d=zoneDone(zi,t), racks=$$('#zone'+z+' .rack');
      racks.forEach(function(r,i){ r.className='rack'+(i<d?' done':(i===d&&t>0&&d<RACKS?' prog':'')); r.setAttribute('aria-label',r.textContent+(i<d?' suskaičiuota':(i===d&&t>0&&d<RACKS?' skaičiuojama':' nepradėta'))); });
      var p=Math.round(d/RACKS*100); tot+=d;
      $('#zp'+z).textContent=p+' %'; $('#zq'+z).textContent=p+' %'; $('#zb'+z).style.width=p+'%';
      $('#zone'+z).classList.toggle('done', d===RACKS);
    });
    var all=Math.round(tot/(RACKS*3)*100);
    $('#pctAll').textContent=all+' %'; $('#planBar').style.width=all+'%';
    var h=$('#hint3'), finished=all>=100;
    $('#stepPlan').disabled=finished; $('#playPlan').disabled=finished;
    if(finished){ h.className='hint ok'; h.innerHTML='Visos zonos suskaičiuotos. Dabar – svarbiausia dalis: <strong>neatitikimai</strong>.'; }
    else { h.className='hint'; h.innerHTML='Spauskite <strong>„Pirmyn“</strong> arba <strong>„Paleisti“</strong>.'; }
  }
  function tick(){ if(state.planTick<TICKS){ state.planTick++; paintPlan(); } }
  $('#stepPlan').addEventListener('click', function(){ tick(); });
  $('#playPlan').addEventListener('click', function(){
    clearTimers();
    if(reduce){ state.planTick=TICKS; paintPlan(); return; }
    var id=setInterval(function(){ tick(); if(state.planTick>=TICKS) clearInterval(id); },450);
    timers.push(id);
  });

  /* ---------- step 4: discrepancies ---------- */
  function renderDiffs(){
    var body=$('#diffBody'); body.innerHTML='';
    var open=0;
    diffs.forEach(function(d,i){
      var rc=state.recounted[i]; var cnt=rc?d.c2:d.c1; var diff=cnt-d.sys;
      if(!rc) open++;
      var tr=document.createElement('tr');
      tr.className = rc ? (diff===0?'r-ok':(diff<0?'r-short':'r-surp')) : '';
      var cls = diff===0?'zero':(diff<0?'neg':'pos');
      tr.innerHTML =
        '<td data-label="Prekė"></td>'+
        '<td data-label="Vieta">'+d.l+'</td>'+
        '<td data-label="Sistemoje" class="num">'+d.sys+'</td>'+
        '<td data-label="Suskaičiuota" class="num">'+cnt+(rc&&d.c2!==d.c1?' <s style="color:#8a9aa9">'+d.c1+'</s>':'')+'</td>'+
        '<td data-label="Skirtumas" class="num '+cls+'">'+sgn(diff)+'</td>'+
        '<td data-label="Būsena" class="stc"></td>';
      $('td',tr).textContent=d.n;
      var st=$('.stc',tr);
      if(rc){
        st.innerHTML='<span class="st st-done">Perskaičiuota</span><span class="recount-note"></span>';
        $('.recount-note',st).textContent=(diff===0?'Skirtumo nėra: ':'')+d.why;
      } else {
        st.innerHTML='<span class="st st-wait">Laukia</span>';
        var b=document.createElement('button'); b.type='button'; b.className='small-btn'; b.textContent='Perskaičiuoti';
        b.setAttribute('aria-label','Perskaičiuoti: '+d.n);
        b.addEventListener('click', function(){ recount(i, b); });
        st.appendChild(b);
      }
      body.appendChild(tr);
    });
    $('#diffOpen').parentNode.innerHTML = open ? '<b id="diffOpen">'+open+'</b> '+(open===1?'pozicija laukia':'pozicijos laukia')+' perskaičiavimo · perskaičiuos Skaičiuotojas 2'
      : 'Viskas perskaičiuota: iš 7 skirtumų liko 5 tikri<b id="diffOpen" hidden>0</b>.';
    $('#recountAll').disabled = !open;
  }
  function recount(i, btn){
    if(btn){ btn.disabled=true; btn.textContent='Skaičiuojama…'; }
    var t=setTimeout(function(){ state.recounted[i]=true; renderDiffs(); var f=$('#recountAll'); if(f.disabled){ $('#nextBtn').focus(); } }, reduce?0:500);
    timers.push(t);
  }
  $('#recountAll').addEventListener('click', function(){
    var btn=this; btn.disabled=true;
    var idx=diffs.map(function(_,i){return i;}).filter(function(i){return !state.recounted[i];});
    var k=0;
    var id=setInterval(function(){ if(k>=idx.length){ clearInterval(id); return; } state.recounted[idx[k++]]=true; renderDiffs(); $('#recountAll').disabled=true; if(k>=idx.length){ clearInterval(id); renderDiffs(); } }, reduce?1:260);
    timers.push(id);
  });

  /* ---------- step 5: report ---------- */
  function renderReport(){
    var body=$('#repBody'); if(body.children.length) return;
    diffs.forEach(function(d){
      var diff=d.c2-d.sys; if(!diff) return;
      var tr=document.createElement('tr');
      tr.innerHTML='<td></td><td class="num '+(diff<0?'neg':'pos')+'">'+sgn(diff)+'</td><td class="num">'+fmt(d.p,2)+' €</td><td class="num '+(diff<0?'neg':'pos')+'">'+eur(diff*d.p)+'</td>';
      $('td',tr).textContent=d.n; body.appendChild(tr);
    });
  }

  show(fromHash(), false);
})();
